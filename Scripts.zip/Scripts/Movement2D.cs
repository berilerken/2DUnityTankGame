using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement2D : MonoBehaviour
{
    // Start is called before the first frame update

    public float speed = 10.0f;
    public float rotationSpeed = 15.0f;
    public GameObject TankBase;
    bool rotate = false;
    bool returnTobase = false;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        float translation = Input.GetAxis("Vertical") * speed * Time.deltaTime;

        float rotation = Input.GetAxis("Horizontal") * rotationSpeed * Time.deltaTime;

        this.transform.Translate(0, translation, 0);
        this.transform.Rotate(0, 0, -rotation);


        if (Input.GetKeyDown(KeyCode.Return))
        {
            LookAtBase();

        }

        
        if (returnTobase)
            returnToBase();


    }


    void LookAtBase()
    {
        Vector3 dVec = (TankBase.transform.position - this.transform.position).normalized;

        float angle = Mathf.Acos((Vector3.Dot(this.transform.up.normalized, dVec)) / (this.transform.up.normalized.magnitude * dVec.magnitude))*Mathf.Rad2Deg;

        Vector3 cross = Vector3.Cross(dVec,this.transform.up);

        if (cross.z > 0)
            angle = angle * -1;

    
        this.transform.Rotate(0, 0, angle);

    }

    void returnToBase()
    {
        Vector3 dVec = (TankBase.transform.position - this.transform.position);
        transform.position += dVec * Time.deltaTime;

        if (dVec.magnitude < 0.2)
            returnTobase = false;

    }

    private void Flip(){
        transform.Rotate(0f, 180f, 0f);
    }


}

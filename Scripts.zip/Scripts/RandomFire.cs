using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomFire : MonoBehaviour
{
    public Transform firePoint;
    public GameObject bulletPrefab;
    public Vector2 m_Offset;
    private float m_FireTime = 0.0f;
   
    private void Update()
    {
        if(Time.time > this.m_FireTime)
        {
            this.m_FireTime = Time.time + (float)Random.Range(this.m_Offset.x, this.m_Offset.y);
            Instantiate(this.bulletPrefab, firePoint.position, firePoint.rotation);
        }
    }
}

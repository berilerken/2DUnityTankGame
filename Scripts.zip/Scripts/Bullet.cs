using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    // Start is called before the first frame update

    public float speed = 20f;
    public int damage=1;
    public Rigidbody2D rb;

    public AudioClip a;
    
    

    void Start()
    {
        rb.velocity = transform.up * speed;

    }

   void OnTriggerEnter2D(Collider2D hitInfo){

       Destroy_Objects enemy = hitInfo.GetComponent<Destroy_Objects>();
       if(enemy != null){
           enemy.TakeDamage(damage);
       }
       myTankDie myTank = hitInfo.GetComponent<myTankDie>();
       if(myTank != null){
           myTank.TakeDamage(damage);
       }
       
       Destroy(gameObject);
       
       if(myTank == null){
         AudioSource.PlayClipAtPoint(a,transform.position);
         
       }

       if(enemy == null){
         AudioSource.PlayClipAtPoint(a,transform.position);
       }


       
   }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy_Objects : MonoBehaviour
{
    public int health = 1;
    public AudioClip c;

    public void TakeDamage(int damage){

        health -= damage;

        if(health <= 0){
            Die();
        }
    }
    
    void Die(){

        //Instantiate(deathEffect, transform.position, Queternion.identify);
        Destroy(gameObject);
        AudioSource.PlayClipAtPoint(c,transform.position);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class myTankDie : MonoBehaviour
{
    public int health = 1;
    public AudioClip b;
    string sceneName= "end";

    public void TakeDamage(int damage){

        health -= damage;

        if(health <= 0){
            Die();
        }
    }
    
    void Die(){
      Destroy(gameObject);
      AudioSource.PlayClipAtPoint(b,transform.position);
      SceneManager.LoadScene (sceneName);

    }
}


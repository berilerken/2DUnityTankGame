using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class End_Game : MonoBehaviour
{
    public AudioClip e;
    void Start()
    {
        AudioSource.PlayClipAtPoint(e,transform.position);
    }

    void Update()
    {
        karakterHareket();
    }
    void karakterHareket()
    {
        float hareket_hizi = 40f;
        this.transform.Translate(hareket_hizi * Time.deltaTime,0,0);
    }
}

using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSwitcher : MonoBehaviour
{
    string sceneName="main";

    

     void Update()
    {
        
        if (Input.GetKeyDown("space"))
        {
            SceneManager.LoadScene (sceneName);
        }

    }

}
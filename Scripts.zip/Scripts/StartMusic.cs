using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartMusic : MonoBehaviour
{
    public AudioClip k;
    void Start()
    {
        AudioSource.PlayClipAtPoint(k,transform.position);
    }

}

